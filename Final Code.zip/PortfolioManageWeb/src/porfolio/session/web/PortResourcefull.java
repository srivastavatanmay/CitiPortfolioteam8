package porfolio.session.web;


import java.util.List;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

import portfolio.session.ejb.PortfolioManagerBeanLocal;

import portfolio.session.jpa.Company;
import portfolio.session.jpa.Portfolio;
import portfolio.session.jpa.PortfolioStock;
import portfolio.session.jpa.Transaction;



@Path("/product")
public class PortResourcefull {

	private PortfolioManagerBeanLocal bean; 
	
	 public PortResourcefull() {
		// TODO Auto-generated constructor stub
		try {

			
        	InitialContext context = new InitialContext();
        	
            bean = (PortfolioManagerBeanLocal) context.lookup("java:app/PortfolioSessionBeansEJB/PortfolioManagerBean!portfolio.session.ejb.PortfolioManagerBeanLocal");
        }
		catch (NamingException ex) {}
	}
	
	@GET
	@Produces("application/json")
	public List<Portfolio> getProducts(@QueryParam("filter") @DefaultValue("") String filter) {

		if (bean == null) 
			return null;
		
		if (filter.length() == 0) {
			return bean.getAllStocks();
		}
		else {
			System.out.println("=========================================================error occured");
			return null;
		}
	}

/*	@GET
	@Produces("application/json")
    @Path("/{categoryName}")
	public List<Product> getProductsInCategory(@PathParam("categoryName")String categoryName) {

		if (bean == null) 
			return null;
		
		return bean.getProductsInCategory(categoryName);	
	}*/
	
	/*@POST
	@Path("/post")
	@Consumes("text/plain")
	public Response postStrMsg(String msg)
	{
		String output =  "yeeh its working : " + msg;
		bean.addBook(msg);
		return Response.status(200).entity(output).build();
	}*/
	
/*	@POST
	@Path("/company_info")
	@Consumes("text/plain")
	@Produces("application/json")
	public Company getCompanyInfo(String companyName)
	{
		String output =  "yeeh its working : " + companyName;
		Company companyInfoObject = bean.getCompanyInfo(companyName);
		System.out.println(output);
		return companyInfoObject;	
		
	}*/

	@GET
	@Path("/company_info")
	@Produces("application/json")
	public Company getCompanyInfo(@QueryParam("companyName") String company_name){
		
		String output =  "yeeh its working : in getcompanyinfo " + company_name;
		Company companyInfoObject = bean.getCompanyInfo(company_name);
		System.out.println(output);
		return companyInfoObject;
		
	}
	
	
	@GET
	@Path("/list_of_companies")
	@Produces("application/json")
	public List<Company> getCompanies(@QueryParam("filter") @DefaultValue("") String filter) {

		if (bean == null) 
			return null;
		
		if (filter.length() == 0) {
			return bean.getAllCompanies();
		}
		else {
			System.out.println("=========================================================error occured");
			return null;
		}
	}
	
	@POST
	@Path("/addNewCompany")
	@Consumes("application/x-www-form-urlencoded")
	@Produces("text/plain")
	public Response addNewCompanyToPortfolio(@FormParam("ticker") String ticker, @FormParam("volumeOwned") String volowned,@FormParam("addDate") String addDate,@FormParam("costprice") String costprice)
	{
		String output =  "SUCCESSFULLY UPDATED in addnewcompany " + ticker;
//		bean.addBook(msg);
		
		int VolumeCount = Integer.parseInt(volowned);
		double CostPrice = Double.parseDouble(costprice);
		
		System.out.println(ticker + VolumeCount + addDate + CostPrice);
		bean.calculateAllParam(ticker, VolumeCount, addDate, CostPrice);
		
		bean.updateTransaction(ticker, VolumeCount, addDate, CostPrice);
		System.out.println("9");	
		return Response.status(200).entity(output).build();
	}
	
	
	@GET
	@Path("/allTransactions")
	@Produces("application/json")
	public List<Transaction> getAllCompanyTransaction(@QueryParam("filter") @DefaultValue("") String filter) {

		if (bean == null) 
			return null;
		
		if (filter.length() == 0) {
			return bean.getAllTransaction();
		}
		else {
			System.out.println("=========================================================error occured");
			return null;
		}
	}
	
	@GET
	@Path("/getCompanyTransaction")
	@Produces("application/json")
	public List<Transaction> GetCompanyTransaction(@QueryParam("companyName") String company_name){
		
		String output =  "yeeh its working : in getcompanytransaction " + company_name;
		List<Transaction> companyTransaction = bean.getCompanyTransaction(company_name);
		System.out.println(output);
		return companyTransaction;
		
	}
	
	@POST
	@Path("/sellExistingStock")
	@Consumes("application/x-www-form-urlencoded")
	@Produces("text/plain")
	public Response sellExisitingStockFunction(@FormParam("ticker") String ticker, @FormParam("volumeOwned") String volowned,@FormParam("addDate") String addDate,@FormParam("costprice") String costprice)
	{
		String output =  "SUCCESSFULLY UPDATED in sellexisting" + ticker;
//		bean.addBook(msg);
		
		int VolumeCount = Integer.parseInt(volowned);
		VolumeCount = VolumeCount * (-1);
		double CostPrice = Double.parseDouble(costprice);
		
		System.out.println(ticker + VolumeCount + addDate + CostPrice);
		boolean return_flag = bean.calculateAllParam(ticker, VolumeCount, addDate, CostPrice);
		
		if(return_flag == false)
		{
			System.out.println("existing stock count is less than vol");
			return Response.status(200).entity(output + "You don't have those many stocks!").build();
		}
		
		bean.updateTransaction(ticker, VolumeCount, addDate, CostPrice);
		System.out.println("9");	
		return Response.status(200).entity(output).build();
	}
	
/*	@POST
	@Path("/compareCompanies")
	@Consumes("application/x-www-form-urlencoded")
	@Produces("text/plain")
	public List<Company> compareCompanies(@FormParam("ticker1") String ticker1, @FormParam("ticker2") String ticker2,@FormParam("ticker3") String ticker3)
	{
		String output =  "yeeh its working : " + ticker1+ ticker2 + ticker3;
//		bean.addBook(msg);
		
		List<Company> comparelist = bean.compareCompanies(ticker1, ticker2, ticker3);
		System.out.println("updating Complete");	
		return comparelist;
	}
	*/
	
	@GET
	@Path("/getSinglePortfolio")
	@Produces("application/json")
	public Portfolio GetSinglePortfolioInfo(@QueryParam("companyName") String companyName){
		
		String output =  "yeeh its working : in single portfolio info " + companyName;
		Portfolio portfolioInfoObject = bean.getPortfolioInfo(companyName);
		System.out.println(output);
		return portfolioInfoObject;
		
	}
	
	/*@GET
	@Path("/getPortfolioStocks")
	@Produces("application/json")
	public List<PortfolioStock> GetPortfolioStocks(@QueryParam("companyName") String companyName){
		
		String output =  "yeeh its working : in single portfolio info " + companyName;
		List<PortfolioStock> portfolioInfoObject = bean.getAllStocksInportfolio();
		System.out.println(output);
		return portfolioInfoObject;
		
	}*/
	
	
}
