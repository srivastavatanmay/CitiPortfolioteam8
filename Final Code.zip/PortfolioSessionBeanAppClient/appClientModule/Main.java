import java.util.List;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;

import portfolio.session.ejb.PortfolioManagerBeanRemote;

import portfolio.session.jpa.Portfolio;


public class Main {
	
	
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	

			try {
				
				// Create Properties for JNDI InitialContext.
				Properties prop = new Properties();
				prop.put(Context.INITIAL_CONTEXT_FACTORY, org.jboss.naming.remote.client.InitialContextFactory.class.getName()); 
				prop.put(Context.URL_PKG_PREFIXES, "org.jboss.ejb.client.naming");
				prop.put(Context.PROVIDER_URL, "http-remoting://localhost:8080");
				prop.put("jboss.naming.client.ejb.context", true);
				
				// Create the JNDI InitialContext.
				Context context = new InitialContext(prop);
				
				// Formulate the full JNDI name for the Diary session bean.
				String appName     = "PortfolioSessionBeans";
				String moduleName  = "PortfolioSessionBeansEJB";
				String beanName    = "PortfolioManagerBean";
				String packageName = "portfolio.session.ejb";
				String className   = "PortfolioManagerBeanRemote";
				
				// Lookup the bean using the full JNDI name.
				String fullJndiName = String.format("%s/%s/%s!%s.%s", appName, moduleName, beanName, packageName, className);
				PortfolioManagerBeanRemote bean = (PortfolioManagerBeanRemote) context.lookup(fullJndiName);

				/*bean.addBook("samplebooks1");
				
				List<Book> books = bean.getAllBooks();*/
				
				List<Portfolio> personalStocks = bean.getAllStocks();
				
				for(Portfolio newstock : personalStocks)
				{
					System.out.println(newstock + "\n");
				}
				
				
				
			} catch (Exception ex) {
				System.out.println("Exception: " + ex.getMessage());
			}
		
	
	}

	/* (non-Java-doc)
	 * @see java.lang.Object#Object()
	 */
	public Main() {
		super();
	}

}