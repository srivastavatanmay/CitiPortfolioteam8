package portfolio.session.ejb;

import java.math.BigDecimal;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.Remote;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;


import portfolio.session.jpa.Company;
import portfolio.session.jpa.Portfolio;
import portfolio.session.jpa.PortfolioStock;
import portfolio.session.jpa.Transaction;


/**
 * Session Bean implementation class PortfolioManagerBean
 */
@Stateless
@Local(PortfolioManagerBeanLocal.class)
@Remote(PortfolioManagerBeanRemote.class)
public class PortfolioManagerBean implements PortfolioManagerBeanRemote, PortfolioManagerBeanLocal {

	/**
	 * Default constructor. 
	 */

	@PersistenceContext(name="PortfolioSessionJPA-PU")
	private EntityManager em;
	public PortfolioManagerBean() {
		// TODO Auto-generated constructor stub
	}
	/*@Override
	public void addBook(String name) {
		// TODO Auto-generated method stub


//        Product prod1 = new Product();
		Book book1 = new Book();
		book1.setName(name);
        em.persist(book1);
        System.out.println("Just persisted product: " + book1);

	}
	@Override
	public List<Book> getAllBooks() {
		// TODO Auto-generated method stub


		TypedQuery<Book> query = em.createQuery("SELECT b FROM Book AS b", Book.class);

        // Execute the query, and get a collection of entities back.
        List<Book> books = query.getResultList();


}*/
	@Override
	public List<Portfolio> getAllStocks() {
		// TODO Auto-generated method stub
		TypedQuery<Portfolio> query = em.createQuery("SELECT b FROM Portfolio AS b", Portfolio.class);
		// Execute the query, and get a collection of entities back.
		List<Portfolio> personalStocks = query.getResultList();
		return personalStocks;
	}

	@Override
	public Company getCompanyInfo(String companyName) {
		// TODO Auto-generated method stub

		TypedQuery<Company> query = em.createQuery("SELECT b FROM Company AS b WHERE ticker = \'" + companyName + "\'", Company.class);
		// Execute the query, and get a collection of entities back.
		Company  companyInfo = query.getSingleResult();
		return companyInfo;

	}
	@Override
	public List<Company> getAllCompanies() {
		// TODO Auto-generated method stub

		TypedQuery<Company> query = em.createQuery("SELECT c FROM Company AS c", Company.class);

		// Execute the query, and get a collection of entities back.
		List<Company> companies = query.getResultList();
		return companies;

	}
	
	public void deletePortfolio(String companyName)
	{
	
		Query query = em.createQuery("DELETE FROM Portfolio AS b WHERE ticker = \'" + companyName + "\'");
        int deleted = query.executeUpdate();
		query.executeUpdate();
		
	}
	@Override
	public boolean calculateAllParam(String ticker, int TransactionVolumeCount, String addDate, double CostPrice) {
		// TODO Auto-generated method stub
		System.out.println("1");
		Company company_Info = getCompanyInfo(ticker);
		List<Portfolio> allPortfolio = getAllStocks();
		boolean flag_copy = false;
		int VolumeCount;
		if(TransactionVolumeCount < 0)
			flag_copy = true;
		double open = company_Info.getOpen();
		double high = company_Info.getHigh();
		double low = company_Info.getLow();		
		boolean return_flag = true;
		double live = (high + low)/2;
		double Gain = live - open;	    
		double Total_Gain = Gain * TransactionVolumeCount;	    
		double Gain_pc = Gain * 100 / open;
		Portfolio requirePFolio = null;
		for(Portfolio p : allPortfolio)
		{
			System.out.println(flag_copy);
			if(p.getTicker().equals(ticker))
			{
				requirePFolio = p;
				flag_copy = true;
				System.out.println(flag_copy);
				System.out.println("2");
				break;
			}
		}
		if(flag_copy == false)
		{
		    Total_Gain = Gain * TransactionVolumeCount;	
			double cp = CostPrice * TransactionVolumeCount;
			double ocp_Gain_pc =   (live * TransactionVolumeCount - cp) / cp ;
			double ocp_Total_Gain = live * TransactionVolumeCount - cp;	
			Portfolio newPortfolio = new Portfolio();
			
			
			int r = (int) Math.round(cp*100);
		    cp = r / 100.0;
		    r = (int) Math.round(Gain*100);
	        Gain = r / 100.0;
	        r = (int) Math.round(Gain_pc*100);
	        Gain_pc = r / 100.0;
	        r = (int) Math.round(live*100);
	        live = r / 100.0;
	        r = (int) Math.round(ocp_Total_Gain*100);
	        ocp_Total_Gain = r / 100.0;
	        r = (int) Math.round(ocp_Gain_pc*100);
	        ocp_Gain_pc = r / 100.0;
	        r = (int) Math.round(Total_Gain*100);
	        Total_Gain = r / 100.0;
	       
	        
		    
		    
			newPortfolio.setCp(cp);
			System.out.println("3");
			newPortfolio.setGain(Gain);
			newPortfolio.setGain_pc(Gain_pc);
			newPortfolio.setLive(live);
			newPortfolio.setOCP_Total_Gain(ocp_Total_Gain);
			newPortfolio.setOCP_Gain_pc(ocp_Gain_pc);
			newPortfolio.setTicker(ticker);
			newPortfolio.setTotal_Gain(Total_Gain);
			newPortfolio.setVol(TransactionVolumeCount);
			System.out.println("4");
			//inserting values into database
//			em.getTransaction().begin();
		    em.persist(newPortfolio); //em.merge(u); for updates
//		    em.getTransaction().commit();
//		    em.close();
		}
		else
		{
			//begin updating values
			
			System.out.println("5");
			VolumeCount = requirePFolio.getVol() + TransactionVolumeCount;
			if(VolumeCount < 0)
			{
				return false;
			}
			if(VolumeCount == 0)
			{
				String deleteCompanyName = requirePFolio.getTicker();
				deletePortfolio(deleteCompanyName);
				return true;
			}
		    Total_Gain = Gain * VolumeCount;	
			double cp = requirePFolio.getCp() + CostPrice * TransactionVolumeCount;
			double ocp_Gain_pc =   (live * VolumeCount - cp) / cp ;
			double ocp_Total_Gain = live * VolumeCount - cp;
			
			int r = (int) Math.round(cp*100);
		    cp = r / 100.0;
		    r = (int) Math.round(Gain*100);
	        Gain = r / 100.0;
	        r = (int) Math.round(Gain_pc*100);
	        Gain_pc = r / 100.0;
	        r = (int) Math.round(live*100);
	        live = r / 100.0;
	        r = (int) Math.round(ocp_Total_Gain*100);
	        ocp_Total_Gain = r / 100.0;
	        r = (int) Math.round(ocp_Gain_pc*100);
	        ocp_Gain_pc = r / 100.0;
	        r = (int) Math.round(Total_Gain*100);
	        Total_Gain = r / 100.0;
	        
			requirePFolio.setCp(cp);
			requirePFolio.setGain(Gain);
			requirePFolio.setGain_pc(Gain_pc);
			requirePFolio.setLive(live);
			requirePFolio.setOCP_Total_Gain(ocp_Total_Gain);
			requirePFolio.setOCP_Gain_pc(ocp_Gain_pc);
			requirePFolio.setTicker(ticker);
			requirePFolio.setTotal_Gain(Total_Gain);
			requirePFolio.setVol(VolumeCount);
			em.persist(requirePFolio);
			System.out.println("6");
//		    em.getTransaction().commit();
//		    em.close();
		}	
		System.out.println("7");
		return true;
	}
	@Override
	public void updateTransaction(String ticker, int VolumeCount, String addDate, double CostPrice) {
		// TODO Auto-generated method stub
		Transaction newTransaction = new Transaction();
		
		newTransaction.setTicker(ticker);
		newTransaction.setNoOfUnits(VolumeCount);
		newTransaction.setTransactionDate(addDate);
		int r = (int) Math.round(CostPrice*100);
	    CostPrice = r / 100.0;
		newTransaction.setUnitprice(CostPrice);
        em.persist(newTransaction);
        System.out.println("Just persisted product: " + newTransaction);
        
        System.out.println("10");
		
		
	}
	@Override
	public List<Transaction> getAllTransaction() {
		// TODO Auto-generated method stub
		
		TypedQuery<Transaction> query = em.createQuery("SELECT t FROM Transaction AS t", Transaction.class);

		// Execute the query, and get a collection of entities back.
		List<Transaction> AllTransactions = query.getResultList();
		return AllTransactions;
		
	}
	@Override
	public List<Transaction> getCompanyTransaction(String companyName) {
		// TODO Auto-generated method stub

		TypedQuery<Transaction> query = em.createQuery("SELECT b FROM Transaction AS b WHERE ticker = \'" + companyName + "\'", Transaction.class);

		// Execute the query, and get a collection of entities back.
		List<Transaction>  transactionInfo = query.getResultList();
		return transactionInfo;
	}
	
	//Compare 3 companies
	@Override
	public List<Company> compareCompanies(String ticker1, String ticker2, String ticker3) {
		// TODO Auto-generated method stub
		List<Company> compareResult = null;
		
		TypedQuery<Company> query = em.createQuery("SELECT b FROM Company AS b WHERE ticker = '" + ticker1 + "'" + 
											"or ticker='" + ticker2 + "'" + "or ticker='" + ticker3 + "'", Company.class);

		// Execute the query, and get a collection of entities back.
		compareResult = query.getResultList();
		return compareResult;
	}
	@Override
	public Portfolio getPortfolioInfo(String companyName) {
		// TODO Auto-generated method stub
		TypedQuery<Portfolio> query = em.createQuery("SELECT b FROM Portfolio AS b WHERE ticker = \'" + companyName + "\'", Portfolio.class);

		// Execute the query, and get a collection of entities back.
		Portfolio  companyinPorfolioInfo = query.getSingleResult();
		return companyinPorfolioInfo;
		
	}
/*	@Override
	public List<PortfolioStock> getAllStocksInportfolio() {
		// TODO Auto-generated method stub
		TypedQuery<PortfolioStock> query = em.createQuery("SELECT ticker, vol, live, gain, total_Gain, gain_pc, cp, OCP_Gain_pc, OCP_Total_Gain FROM PortfolioStock AS b", PortfolioStock.class);

		// Execute the query, and get a collection of entities back.
		List<PortfolioStock> personalStocks = query.getResultList();
		return personalStocks;
	}*/
	
}



/*public void calculateAllParam(String ticker, int VolumeCount, String addDate,double CostPrice)
	{

}
 */