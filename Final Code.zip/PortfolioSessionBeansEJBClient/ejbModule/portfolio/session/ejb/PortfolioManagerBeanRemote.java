package portfolio.session.ejb;

import java.util.List;

import javax.ejb.Remote;


import portfolio.session.jpa.Company;
import portfolio.session.jpa.Portfolio;
import portfolio.session.jpa.PortfolioStock;
import portfolio.session.jpa.Transaction;

@Remote
public interface PortfolioManagerBeanRemote {

/*	void addBook(String name);
    List<Book> getAllBooks();*/
    List<Portfolio> getAllStocks();
    List<Company> getAllCompanies();
    Company getCompanyInfo(String companyName);
    Portfolio getPortfolioInfo(String companyName);
    boolean calculateAllParam(String ticker, int VolumeCount, String addDate,double CostPrice);
    void updateTransaction(String ticker, int VolumeCount, String addDate,double CostPrice);
    List<Transaction> getAllTransaction();
    List<Transaction> getCompanyTransaction(String companyName);
    List<Company> compareCompanies(String company1, String company2, String company3);
//    List<PortfolioStock> getAllStocksInportfolio();
//	void addNewCompany(Portfolio newCompany);

//	List<Company> compareCompanies(String company1, String company2);

    
}
