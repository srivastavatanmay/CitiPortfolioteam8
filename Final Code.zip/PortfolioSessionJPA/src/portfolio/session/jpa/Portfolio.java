package portfolio.session.jpa;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the portfolio database table.
 * 
 */
@Entity
@NamedQuery(name="Portfolio.findAll", query="SELECT p FROM Portfolio p")
public class Portfolio implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String ticker;

	private double cp;

	private double gain;

	private double gain_pc;

	private double live;

	private double OCP_Gain_pc;

	private double OCP_Total_Gain;

	private double total_Gain;

	private int vol;

	public Portfolio() {
	}

	public String getTicker() {
		return this.ticker;
	}

	public void setTicker(String ticker) {
		this.ticker = ticker;
	}

	public double getCp() {
		return this.cp;
	}

	public void setCp(double cp) {
		this.cp = cp;
	}

	public double getGain() {
		return this.gain;
	}

	public void setGain(double gain) {
		this.gain = gain;
	}

	public double getGain_pc() {
		return this.gain_pc;
	}

	public void setGain_pc(double gain_pc) {
		this.gain_pc = gain_pc;
	}

	public double getLive() {
		return this.live;
	}

	public void setLive(double live) {
		this.live = live;
	}

	public double getOCP_Gain_pc() {
		return this.OCP_Gain_pc;
	}

	public void setOCP_Gain_pc(double OCP_Gain_pc) {
		this.OCP_Gain_pc = OCP_Gain_pc;
	}

	public double getOCP_Total_Gain() {
		return this.OCP_Total_Gain;
	}

	public void setOCP_Total_Gain(double OCP_Total_Gain) {
		this.OCP_Total_Gain = OCP_Total_Gain;
	}

	public double getTotal_Gain() {
		return this.total_Gain;
	}

	public void setTotal_Gain(double total_Gain) {
		this.total_Gain = total_Gain;
	}

	public int getVol() {
		return this.vol;
	}

	public void setVol(int vol) {
		this.vol = vol;
	}

}