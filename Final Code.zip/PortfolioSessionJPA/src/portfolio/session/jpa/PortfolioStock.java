package portfolio.session.jpa;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the portfolio_stocks database table.
 * 
 */
@Entity
@Table(name="portfolio_stocks")
@NamedQuery(name="PortfolioStock.findAll", query="SELECT p FROM PortfolioStock p")
public class PortfolioStock implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String ticker;

	private double cp;

	private BigDecimal gain;

	private BigDecimal gain_pc;

	private BigDecimal live;

	private double OCP_Gain_pc;

	private double OCP_Total_Gain;

	private int pid;

	private BigDecimal total_Gain;

	private int vol;

	public PortfolioStock() {
	}

	public String getTicker() {
		return this.ticker;
	}

	public void setTicker(String ticker) {
		this.ticker = ticker;
	}

	public double getCp() {
		return this.cp;
	}

	public void setCp(double cp) {
		this.cp = cp;
	}

	public BigDecimal getGain() {
		return this.gain;
	}

	public void setGain(BigDecimal gain) {
		this.gain = gain;
	}

	public BigDecimal getGain_pc() {
		return this.gain_pc;
	}

	public void setGain_pc(BigDecimal gain_pc) {
		this.gain_pc = gain_pc;
	}

	public BigDecimal getLive() {
		return this.live;
	}

	public void setLive(BigDecimal live) {
		this.live = live;
	}

	public double getOCP_Gain_pc() {
		return this.OCP_Gain_pc;
	}

	public void setOCP_Gain_pc(double OCP_Gain_pc) {
		this.OCP_Gain_pc = OCP_Gain_pc;
	}

	public double getOCP_Total_Gain() {
		return this.OCP_Total_Gain;
	}

	public void setOCP_Total_Gain(double OCP_Total_Gain) {
		this.OCP_Total_Gain = OCP_Total_Gain;
	}

	public int getPid() {
		return this.pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public BigDecimal getTotal_Gain() {
		return this.total_Gain;
	}

	public void setTotal_Gain(BigDecimal total_Gain) {
		this.total_Gain = total_Gain;
	}

	public int getVol() {
		return this.vol;
	}

	public void setVol(int vol) {
		this.vol = vol;
	}

}