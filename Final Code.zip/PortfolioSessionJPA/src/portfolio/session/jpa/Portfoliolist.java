package portfolio.session.jpa;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the portfoliolist database table.
 * 
 */
@Entity
@NamedQuery(name="Portfoliolist.findAll", query="SELECT p FROM Portfoliolist p")
public class Portfoliolist implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int pid;

	private String portfolioName;

	public Portfoliolist() {
	}

	public int getPid() {
		return this.pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public String getPortfolioName() {
		return this.portfolioName;
	}

	public void setPortfolioName(String portfolioName) {
		this.portfolioName = portfolioName;
	}

}