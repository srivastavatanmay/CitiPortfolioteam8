package portfolio.session.jpa;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the transactions database table.
 * 
 */
@Entity
@Table(name="transactions")
@NamedQuery(name="Transaction.findAll", query="SELECT t FROM Transaction t")
public class Transaction implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="id_transactions")
	private int idTransactions;

	@Column(name="no_of_units")
	private int noOfUnits;

	private String ticker;

	@Column(name="transaction_date")
	private String transactionDate;

	private double unitprice;

	public Transaction() {
	}

	public int getIdTransactions() {
		return this.idTransactions;
	}

	public void setIdTransactions(int idTransactions) {
		this.idTransactions = idTransactions;
	}

	public int getNoOfUnits() {
		return this.noOfUnits;
	}

	public void setNoOfUnits(int noOfUnits) {
		this.noOfUnits = noOfUnits;
	}

	public String getTicker() {
		return this.ticker;
	}

	public void setTicker(String ticker) {
		this.ticker = ticker;
	}

	public String getTransactionDate() {
		return this.transactionDate;
	}

	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}

	public double getUnitprice() {
		return this.unitprice;
	}

	public void setUnitprice(double unitprice) {
		this.unitprice = unitprice;
	}

}